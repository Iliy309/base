//
//  Constants.swift
//  Skymometer
//
//  Created by Максим Соловьёв on 13.01.2021.
//

import Foundation

let apiKey = "404697b6acf8ccc6c50d4390317588c5"
