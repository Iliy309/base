//
//  Course.swift
//  Networking
//
//  Created by Екатерина Батеева on 11.01.2021.
//  Copyright © 2021 Alexey Efimov. All rights reserved.
//

import Foundation

struct Course: Codable {
    let name: String?
    let imageUrl: String?
    let numberOfLessons: String?
    let numberOfTests: String?
    
//    enum CodingKeys: String, CodingKey {
//        case name = "Name"
//        case imageUrl = "ImageUrl"
//        case numberOfLessons = "Number_of_lessons"
//        case numberOfTests = "Number_of_tests"
//    }
    
    init(courseData: [String: Any]) {
        name = courseData["name"] as? String
        imageUrl = courseData["imageUrl"] as? String
        numberOfLessons = courseData["number_of_lessons"] as? String
        numberOfTests = courseData["number_of_tests"] as? String
    }
    
    static func getCourses(from value: Any) -> [Course] {
        guard let coursesData = value as? [[String: Any]] else { return [] }
        return coursesData.compactMap { Course(courseData: $0) }
    }
    
}

struct WebsiteDescription: Decodable {
    let courses: [Course]?
    let websiteDescription: String?
    let websiteName: String?
}

struct CourseV3: Codable {
    let name: String
    let imageUrl: String
    let numberOfLessons: String
    let numberOfTests: String
}
