//
//  2.swift
//  apiApp
//
//  Created by Apple on 14.01.2021.
//
import UIKit
import MapKit

extension ViewController {
    func getDirection(){
        guard let location = locationManager.location?.coordinate else { return }
        guard let request = createDirectionsRequest(from: location) else { return }
        let directions = MKDirections(request: request)
        
        directions.calculate { (response, error) in
            if let error = error {
                print(error)
                return
            }
            guard let response = response else { return }
            
            for route in response.routes {
                self.mapView.addOverlay(route.polyline)
                self.mapView.setVisibleMapRect(route.polyline.boundingMapRect, animated: true)
                
//                let distance = route.distance
//                let time = route.expectedTravelTime
                
            }
        }
    }
    
    func createDirectionsRequest(from coordinate: CLLocationCoordinate2D) -> MKDirections.Request?{
        guard let destinationCoordinate = placeCoordinate else { return nil }
        let startingLocation = MKPlacemark(coordinate: coordinate)
        let destination = MKPlacemark(coordinate: destinationCoordinate)
        
        let request = MKDirections.Request()
        request.source = MKMapItem(placemark: startingLocation)
        request.destination = MKMapItem(placemark: destination)
        request.transportType = .walking
        request.requestsAlternateRoutes = true
        
        return request
    }
}
