//
//  10.swift
//  apiApp
//
//  Created by Дмитрий on 17.01.2021.
//


import UIKit

extension ViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
            return true
        }
    
    @objc func handleTap(_ sender:UITapGestureRecognizer){
        if !self.customView.isHidden {
            animationHide()
            openTableButton.setImage(UIImage(systemName: "line.horizontal.3.circle"), for: .normal)
        }
    }
}
