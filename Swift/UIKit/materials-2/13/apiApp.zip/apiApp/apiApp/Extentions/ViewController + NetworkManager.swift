//
//  1.swift
//  apiApp
//
//  Created by Apple on 14.01.2021.
//


import UIKit
import Alamofire

extension ViewController {
    
    func fetchWCfromNetwork() {
        let url = "https://apidata.mos.ru/v1/datasets/842/rows/?api_key="
        AF.request("\(url)\(apiKey)")
            .responseJSON { (dataResponse) in
                switch dataResponse.result {
                case .success(_):
                    guard let data = dataResponse.data else { return }
                    do {
                        self.waterClosetArray = try JSONDecoder().decode([WaterClosetData].self, from: data)
                        self.saveWCinDefaults()
                        self.saveSupportingData()
                        self.dispatchQueue()
                        self.showOkAlert(title: "Отлично", message: "Данные обновлены")
                    } catch let error {
                        print(error)
                    }
                case .failure(let error):
                    print("\n Failure: \(error.localizedDescription)")
                    self.getSupportingData()
                    self.getWCfromDefaults()
                    self.showOkAlert(title: "Проблемы с сетью", message: "Последний раз данные обновлялись: \(self.supportData.updateDataDay)")
                }
        }
    }
}

