//
//  CustomPointAnnotation.swift
//  apiApp
//
//  Created by Apple on 14.01.2021.
//

import UIKit
import MapKit

class CustomPointAnnotation: MKPointAnnotation {

}
