//
//  ListTableViewCell.swift
//  apiApp
//
//  Created by Apple on 13.01.2021.
//

import UIKit

class ListTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameWC: UILabel!
    @IBOutlet weak var directionsWC: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
