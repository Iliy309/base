//
//  Constance.swift
//  apiApp
//
//  Created by Apple on 12.01.2021.
//

import Foundation

let apiKey = "014ff8b77bc24e82f4d4f81da04e720d"
