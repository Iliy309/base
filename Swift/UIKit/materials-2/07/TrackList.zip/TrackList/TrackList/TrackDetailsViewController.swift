//
//  TrackDetailsViewController.swift
//  TrackList
//
//  Created by Екатерина Батеева on 21.12.2020.
//

import UIKit

class TrackDetailsViewController: UIViewController {
    @IBOutlet var artCoverImageView: UIImageView!
    @IBOutlet var trackLabel: UILabel!
    
    var track: Track!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        artCoverImageView.image = UIImage(named: track.track)
        trackLabel.text = track.track
    }

}
