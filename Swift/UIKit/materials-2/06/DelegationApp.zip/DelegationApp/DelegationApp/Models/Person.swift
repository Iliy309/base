
struct Person {
    let name: String
    let surname: String
}
