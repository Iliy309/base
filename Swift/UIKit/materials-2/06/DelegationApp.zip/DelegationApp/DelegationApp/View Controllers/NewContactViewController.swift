
import UIKit

protocol NewContactViewControllerDelegate: AnyObject {
    func saveContact(fullName: String)
}

protocol FullyNameProtocol {
    var fullName: String { get }
}

class NewContactViewController: UIViewController, FullyNameProtocol {

    @IBOutlet var firstNameTextField: UITextField!
    @IBOutlet var lastNameTextField: UITextField!
    
    weak var delegate: NewContactViewControllerDelegate?
    
    var fullName: String {
        let person = Person(
            name: firstNameTextField.text ?? "",
            surname: lastNameTextField.text ?? ""
        )
        
        return "\(person.name) \(person.surname)"
    }
    
    @IBAction func doneButtonPressed() {
        delegate?.saveContact(fullName: fullName)
        dismiss(animated: true)
    }
    
    @IBAction func canceButtonPressed() {
        dismiss(animated: true)
    }
}
