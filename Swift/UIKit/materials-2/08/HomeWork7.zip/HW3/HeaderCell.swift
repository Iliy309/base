

import UIKit

class HeaderCell: UITableViewCell {
    @IBOutlet var personLabel: UILabel!
}
