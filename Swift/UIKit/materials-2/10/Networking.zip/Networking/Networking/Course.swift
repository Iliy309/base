//
//  Course.swift
//  Networking
//
//  Created by Екатерина Батеева on 11.01.2021.
//  Copyright © 2021 Alexey Efimov. All rights reserved.
//

import Foundation

struct Course: Decodable {
    let name: String?
    let imageUrl: String?
    let number_of_lessons: Int?
    let number_of_tests: Int?
}

struct WebsiteDescription: Decodable {
    let courses: [Course]?
    let websiteDescription: String?
    let websiteName: String?
}
